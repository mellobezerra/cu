@extends('layouts.app-master')
 
@section('content')

<div class="bg-light p-4 rounded">
    	<h1>Usuário</h1>
    	<div class="lead">
        	Dados do Usuário
    	</div>
       
    	<div class="mt-2">
        	@include('layouts.partials.messages')
    	</div>
    	
    	<div class="container mt-4">
<form method="POST" action="">
@csrf
<div class="mb-3">
<label for="nome" class="form-label">Nome</label>
<input value="{{ old('nome') }}"
type="text"
class="form-control"
name="nome"
placeholder="Nome" required>
@if ($errors->has('nome'))
<span class="text-danger text-left">{{ $errors->first('nome') }}</span>
@endif
</div>
<div class="mb-3">
<label for="email" class="form-label">Email</label>
<input value="{{ old('email') }}"
type="text"
class="form-control"
name="email"
placeholder="Email" required>
@if ($errors->has('email'))
<span class="text-danger text-left">{{ $errors->first('email') }}</span>
@endif
</div>
<div class="mb-3">
<label for="role" class="form-label">Role</label>
<input value="{{ old('role') }}"
type="text"
class="form-control"
name="role"
placeholder="Role" required>
@if ($errors->has('role'))
<span class="text-danger text-left">{{ $errors->first('role') }}</span>
@endif
</div>
<div class="mb-3">
<label for="password" class="form-label">Password</label>
<input value="{{ old('password') }}"
type="password"
class="form-control"
name="password"
placeholder="Password" required>
@if ($errors->has('password'))
<span class="text-danger text-left">{{ $errors->first('password') }}</span>
@endif
</div>
<button type="submit" class="btn btn-primary">Salvar</button>
<a href="{{ route('produtos.index') }}" class="btn btn-danger">Cancelar</a>
</form>
</div>

    	
</div>

@endsection