

 
<?php $__env->startSection('content'); ?>
	<div class="bg-light p-4 rounded">
    	<h1>Alterar produto</h1>
    	<div class="lead">
           
    	</div>
       
    	<div class="container mt-4">
        	<form method="post" action="<?php echo e(route('produtos.update', $produto->id)); ?>">
            	<?php echo method_field('patch'); ?>
            	<?php echo csrf_field(); ?>
            	<div class="mb-3">
                	<label for="nome" class="form-label">Nome</label>
                	<input value="<?php echo e($produto->nome); ?>"
                    	type="text"
                    	class="form-control"
                    	name="nome"
                    	placeholder="Nome" required>
 
                	<?php if($errors->has('nome')): ?>
                    	<span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                	<?php endif; ?>
            	</div>
            	<div class="mb-3">
                	<label for="marca" class="form-label">Marca</label>
                	<input value="<?php echo e($produto->marca); ?>"
                    	type="text"
                    	class="form-control"
                    	name="marca"
                    	placeholder="Marca" required>
                	<?php if($errors->has('marca')): ?>
                    	<span class="text-danger text-left"><?php echo e($errors->first('marca')); ?></span>
                	<?php endif; ?>
            	</div>
            	<div class="mb-3">
                	<label for="modelo" class="form-label">Modelo</label>
                	<input value="<?php echo e($produto->modelo); ?>"
                    	type="text"
                    	class="form-control"
                    	name="modelo"
                    	placeholder="Modelo" required>
                	<?php if($errors->has('modelo')): ?>
                    	<span class="text-danger text-left"><?php echo e($errors->first('modelo')); ?></span>
                	<?php endif; ?>
            	</div>
            	<div class="mb-3">
                	<label for="quantidade" class="form-label">Quantidade</label>
                	<input value="<?php echo e($produto->quantidade); ?>"
                    	type="text"
                    	class="form-control"
                    	name="quantidade"
                    	placeholder="Quantidade" required>
                	<?php if($errors->has('quantidade')): ?>
                    	<span class="text-danger text-left"><?php echo e($errors->first('quantidade')); ?></span>
                	<?php endif; ?>
            	</div>
            	<div class="mb-3">
                	<label for="preco" class="form-label">Preço</label>
                	<input value="<?php echo e($produto->preco); ?>"
                    	type="text"
                    	class="form-control"
                    	name="preco"
                    	placeholder="Preço" required>
                	<?php if($errors->has('preco')): ?>
                    	<span class="text-danger text-left"><?php echo e($errors->first('preco')); ?></span>
                	<?php endif; ?>
            	</div>
            	
               
 
            	<button type="submit" class="btn btn-primary">Salvar</button>
            	<a href="<?php echo e(route('produtos.index')); ?>" class="btn btn-danger">Cancelar</a>
        	</form>
    	</div>
 
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\crudlaraveltb\resources\views/produtos/edit.blade.php ENDPATH**/ ?>