 
<?php $__env->startSection('content'); ?>
	<form method="post" action="<?php echo e(route('login.perform')); ?>">
    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    	<img class="form-group form-floating mb-3 w-25 mx-auto" src="<?php echo url('assets/images/ifpr_vertical.svg'); ?>" alt="" width="202" height="187">
       
    	<h1 class="h3 mb-3 w-25 fw-normal mx-auto">Login</h1>
 
    	<?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
    	<div class="form-group form-floating mb-3 w-25 mx-auto">
        	<input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail" required="required" autofocus>
        	<label for="floatingName">E-mail</label>
        	<?php if($errors->has('email')): ?>
            	<span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
        	<?php endif; ?>
    	</div>
       
    	<div class="form-group form-floating mb-3 w-25 mx-auto">
        	<input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
        	<label for="floatingPassword">Password</label>
        	<?php if($errors->has('password')): ?>
            	<span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
        	<?php endif; ?>
    	</div>
 
          	<div class="form-group form-floating mb-3 mx-auto">
        	<button class="btn btn-lg btn-primary w-25 mx-auto" type="submit">Login</button>
        	<br/><br/>
        	<a href="<?php echo e(route('home.index')); ?>" class="btn btn-lg btn-secondary w-25 mx-auto">Página Inicial</a>
          	</div>
       
    	<?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paulojr/Documents/www/crudlaraveltb/resources/views/auth/login.blade.php ENDPATH**/ ?>