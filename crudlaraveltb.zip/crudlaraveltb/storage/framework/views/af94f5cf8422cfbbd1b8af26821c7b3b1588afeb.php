 
<?php $__env->startSection('content'); ?>
 
   	<?php if(auth()->guard()->check()): ?>
	   <?php echo $__env->make('layouts.partials.navbarlogged', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
   
	<?php if(auth()->guard()->guest()): ?>
	   <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   	<?php endif; ?>
	<div class="bg-light p-5 rounded">
   
	   <?php if(auth()->guard()->check()): ?>
    	<h1>Dashboard</h1>
    	<p class="lead">Bem-vindo, está é a sua dashboard.</p>
    	<?php endif; ?>
 
    	<?php if(auth()->guard()->guest()): ?>
    	<h1>Bem-vindo</h1>
    	<p class="lead">Por favor, faça o login para entrar na área restrita do sistema</p>
    	<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paulojr/Documents/www/crudlaravelta/resources/views/home/index.blade.php ENDPATH**/ ?>