 
<?php $__env->startSection('content'); ?>
<center>
	<form method="post" action="<?php echo e(route('register.perform')); ?>">
 
    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    	<img class="mb-4" src="<?php echo url('assets/images/ifpr_vertical.svg'); ?>" alt="" width="202" height="187">
       
    	<h1 class="h3 mb-3 fw-normal">Cadastro de usuário</h1>
 
          	<div class="form-group form-floating mb-3 w-25 mx-auto">
        	<input type="text" class="form-control" name="nome" value="<?php echo e(old('nome')); ?>" placeholder="Nome" required="required" autofocus>
        	<label for="floatingNome">Nome</label>
        	<?php if($errors->has('nome')): ?>
            	<span class="text-danger text-left"><?php echo e($errors->first('nome')); ?></span>
        	<?php endif; ?>
    	</div>
 
    	<div class="form-group form-floating mb-3 w-25 mx-auto">
        	<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="email@exemplo.com" required="required">
        	<label for="floatingEmail">E-mail</label>
        	<?php if($errors->has('email')): ?>
            	<span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
        	<?php endif; ?>
    	</div>
       
    	<div class="form-group form-floating mb-3 w-25 mx-auto">
        	<input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
        	<label for="floatingPassword">Senha</label>
        	<?php if($errors->has('password')): ?>
            	<span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
        	<?php endif; ?>
    	</div>
 
    	<div class="form-group form-floating mb-3 w-25 mx-auto">
        	<input type="password" class="form-control" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password" required="required">
        	<label for="floatingConfirmPassword">Confirme a senha</label>
        	<?php if($errors->has('password_confirmation')): ?>
            	<span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
        	<?php endif; ?>
    	</div>
 
    	<div class="form-group form-floating mb-3 mx-auto">
        	<button class="btn btn-lg btn-primary w-25 mx-auto" type="submit">Registrar</button>
        	<br/><br/>
        	<a href="<?php echo e(route('home.index')); ?>" class="btn btn-lg btn-secondary w-25 mx-auto">Página Inicial</a>
          	</div>
       
    	<?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paulojr/Documents/www/crudlaravelta/resources/views/auth/register.blade.php ENDPATH**/ ?>