
 
<?php $__env->startSection('content'); ?>

<div class="bg-light p-4 rounded">
    	<h1>Usuário</h1>
    	<div class="lead">
        	Dados do Usuário
    	</div>
       
    	<div class="mt-2">
        	<?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	</div>
    	
    	<div class="container mt-4">
<form method="POST" action="">
<?php echo csrf_field(); ?>
<div class="mb-3">
<label for="nome" class="form-label">Nome</label>
<input value="<?php echo e(old('nome')); ?>"
type="text"
class="form-control"
name="nome"
placeholder="Nome" required>
<?php if($errors->has('nome')): ?>
<span class="text-danger text-left"><?php echo e($errors->first('nome')); ?></span>
<?php endif; ?>
</div>
<div class="mb-3">
<label for="email" class="form-label">Email</label>
<input value="<?php echo e(old('email')); ?>"
type="text"
class="form-control"
name="email"
placeholder="Email" required>
<?php if($errors->has('email')): ?>
<span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
<?php endif; ?>
</div>
<div class="mb-3">
<label for="role" class="form-label">Role</label>
<input value="<?php echo e(old('role')); ?>"
type="text"
class="form-control"
name="role"
placeholder="Role" required>
<?php if($errors->has('role')): ?>
<span class="text-danger text-left"><?php echo e($errors->first('role')); ?></span>
<?php endif; ?>
</div>
<div class="mb-3">
<label for="password" class="form-label">Password</label>
<input value="<?php echo e(old('password')); ?>"
type="password"
class="form-control"
name="password"
placeholder="Password" required>
<?php if($errors->has('password')): ?>
<span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
<?php endif; ?>
</div>
<button type="submit" class="btn btn-primary">Salvar</button>
<a href="<?php echo e(route('produtos.index')); ?>" class="btn btn-danger">Cancelar</a>
</form>
</div>

    	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\crudlaraveltb\resources\views/users/create.blade.php ENDPATH**/ ?>