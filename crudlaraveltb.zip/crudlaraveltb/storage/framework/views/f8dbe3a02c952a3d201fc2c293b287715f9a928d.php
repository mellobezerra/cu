	
<?php $__env->startSection('content'); ?>
<div class="bg-light p-4 rounded">
<h1>Dados do produto</h1>
<div class="lead">
</div>
<div class="container mt-4">
<div>
Nome: <?php echo e($produto->nome); ?>

</div>
<div>
Marca: <?php echo e($produto->marca); ?>

</div>
<div>
Quantidade: <?php echo e($produto->quantidade); ?>

</div>
<div>
Preço: <?php echo e($produto->preco); ?>

</div>
<div>
Data de vencimento: <?php echo e(date('d/m/Y', strtotime($produto->data_vencimento))); ?>

</div>
</div>
</div>
<div class="mt-4">
<a href="<?php echo e(route('produtos.index')); ?>" class="btn btn-secondary">Voltar</a>
</div>
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\crudlaraveltb\resources\views/produtos/show.blade.php ENDPATH**/ ?>